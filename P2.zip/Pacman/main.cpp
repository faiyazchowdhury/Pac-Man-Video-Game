/* Gatech ECE2035 2015 SPRING PAC MAN
 * Copyright (c) 2015 Gatech ECE2035
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
/** @file main.cpp */
// Include header files for platform
#include "mbed.h"
#include "wave_player.h"
#include "SDFileSystem.h"
#include "PinDetect.h"

// Include header files for pacman project
#include "globals.h"
#include "map_public.h"
#include "pacman.h"
#include "ghost.h"
#include "MMA8452.h"
#include "doubly_linked_list.h"

// Platform initialization
DigitalIn left_pb(p21);  // push bottem
DigitalIn right_pb(p22); // push bottem
DigitalIn up_pb(p23);    // push bottem
DigitalIn down_pb(p24);  // push bottem
uLCD_4DGL uLCD(p9,p10,p11); // LCD (serial tx, serial rx, reset pin;)
Serial pc(USBTX,USBRX);     // used by Accelerometer
MMA8452 acc(p28, p27, 100000); // Accelerometer
AnalogOut DACout(p18);      // speaker
wave_player waver(&DACout); // wav player
SDFileSystem sd(p5, p6, p7, p8, "sd"); // SD card and filesystem (mosi, miso, sck, cs)

DigitalOut myled1(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);
DigitalOut myled4(LED4);

PwmOut led(p25);


void playSound(char * wav);
void countDown(void);


/** Main() is where you start your implementation
    @brief The hints of implementation are in the comments. <br>
    @brief You are expected to implement your code in main.cpp and pacman.cpp. But you could modify any code if you want to make the game work better.
*/
int main()
{   
    // Initialize the timer
    int tick, pre_tick;
    srand (time(NULL));
    Timer timer;
    timer.start();
    tick = timer.read_ms();
    pre_tick = tick;
    
    // Initialize the buttons        
    left_pb.mode(PullUp);  // The variable left_pb will be zero when the pushbutton for moving the player left is pressed    
    right_pb.mode(PullUp); // The variable rightt_pb will be zero when the pushbutton for moving the player right is pressed        
    up_pb.mode(PullUp);    //the variable fire_pb will be zero when the pushbutton for firing a missile is pressed
    down_pb.mode(PullUp);  //the variable fire_pb will be zero when the pushbutton for firing a missile is pressed
    
    // My Variables:
    int orientation = 0;
    int lives = 0;
    int level = 1;
    int score1 = 0;
    int score2 = 0;
    int score3 = 0;
    int score4 = 0;
    led = 0;
    // Menu
    while(1)
    {
        // GameOver
        if(lives < 0){
            score4 = score3;
            score3 = score2;
            score2 = score1;
            score1 = pacman_getScore();
            playSound("/sd/wavfiles/DEATH.wav");
            uLCD.cls();
            uLCD.locate(4,5);
            uLCD.printf("NEVER GIVE UP!");
            countDown();
            uLCD.cls();
        }
        uLCD.cls();
        uLCD.locate(1,1);
        uLCD.printf("Choose your level Press Button!");
        uLCD.locate(4,5);
        uLCD.printf("Lvl 1 (Up)");
        uLCD.locate(4,7);
        uLCD.printf("Lvl 2 (Right)");
        uLCD.locate(4,9);
        uLCD.printf("Lvl 3 (Left)");
        uLCD.locate(4,11);
        uLCD.printf("History (Down)");
        while(up_pb && left_pb && right_pb) {
            if (!up_pb) {
                level = 1;
            } else if (!right_pb) {
                level = 2;
            } else if (!left_pb) {
                level = 3;
            } else if (!down_pb) {
                uLCD.cls();
                uLCD.locate(4,3);
                uLCD.printf("Score1: %d", score1);
                uLCD.locate(4,5);
                uLCD.printf("Score2: %d", score2);
                uLCD.locate(4,7);
                uLCD.printf("Score3: %d", score3);
                uLCD.locate(4,9);
                uLCD.printf("Score4: %d", score4);
                uLCD.locate(4,11);
                uLCD.printf("BACK (DOWN)");
                wait(1);
                while(down_pb){
                    level = 0;
                }
                uLCD.cls();
                uLCD.locate(1,1);
                uLCD.printf("Choose your level Press Button!");
                uLCD.locate(4,5);
                uLCD.printf("Lvl 1 (Up)");
                uLCD.locate(4,7);
                uLCD.printf("Lvl 2 (Right)");
                uLCD.locate(4,9);
                uLCD.printf("Lvl 3 (Left)");
                uLCD.locate(4,11);
                uLCD.printf("History (Down)");
            }
        }
        
        
        

        uLCD.cls();
        map_init();
        pacman_init(8,9, level); // Center of the map

        //Initiate & create & show the 4 ghosts
        ghost_init();
        ghost_create(8,7, 0xFF0000);
        ghost_create(9,7, 0xFFD5F1);
        ghost_create(7,7, 0x00FFFF);
        ghost_create(8,6, 0xF49629);
        ghost_show((DLinkedList*)(get_ghost_list));
        //[Demo of play sound file]
        playSound("/sd/wavfiles/START.wav");  //
        
        
    
        /// 1. Begin the game loop
        while(pacman_getLives() >= 0){
            tick = timer.read_ms(); // Read current time
            ghost_random_walk();

            // Force Level Advance
            if ((!left_pb && (!right_pb || !up_pb || !down_pb)) || (!right_pb && (!left_pb || !up_pb || !down_pb))) {
                uLCD.cls();
                pacman_lvlUp(8,9);
                ghost_init();
                ghost_create(8,7,0xFF0000);
                ghost_create(9,7,0xFFD5F1);
                ghost_create(7,7,0x00FFFF);
                ghost_create(8,6,0xF49629);
                ghost_show((DLinkedList*)(get_ghost_list));
                orientation++;
                map_init();
                playSound("/sd/wavfiles/START.wav");
            } else if (!left_pb) { // Changes orientation
                orientation++;
            } else if (!right_pb) {
                orientation--;
            } else if (!up_pb) {
                orientation = 0;
            } else if (!down_pb) {
                countDown();
            }


            /// 2. Implement the code to get user input and update the Pacman
            double x = 0, y = 0, z = 0;
            if ((orientation%4) == 0) {
                acc.readXYZGravity(&x, &y, &z);
                uLCD.locate(0,1);
                uLCD.printf("Normal   :)");
            } else if ((orientation%4) == 1) {
                acc.readXYZGravity(&y, &x, &z); // Rotate
                y = -y;
                uLCD.locate(0,1);
                uLCD.printf("Right Rot!");
            } else if ((orientation%4) == 2) {
                acc.readXYZGravity(&y, &x, &z); // Rotate
                x = -x;
                uLCD.locate(0,1);
                uLCD.printf("Left Rot!!");
            } else if ((orientation%4) == 3) { // Upside Down
                acc.readXYZGravity(&x, &y, &z);
                x = -x;
                y = -y;
                uLCD.locate(0,1);
                uLCD.printf("Flipped !!");
            }


            if (abs(x) > 0.4 || abs(y) > 0.4) {
                if (abs(x) > abs(y)) {
                    if (x > 0) {
                        pacman_set_action(PACMAN_HEADING_DOWN);
                    } else {
                        pacman_set_action(PACMAN_HEADING_UP);
                    }
                } else {
                    if (y > 0) {
                        pacman_set_action(PACMAN_HEADING_RIGHT);
                    } else {
                        pacman_set_action(PACMAN_HEADING_LEFT);
                    }
                }
            }

            if((tick-pre_tick)>500){ // Time step control
                 pre_tick = tick;
            
            /// 3. Update the Pacman on the screen
            /// -[Hint] You could update the position of Pacman here based on the input at step 2. <br>
            pacman_update_position();
            }
        
        /// 4. Implement the code to check the end of game.
        // CHECK DEATH
        GHOST * ghost = (GHOST *) getHead(get_ghost_list());
        while (ghost!=NULL) {
            int ghostx = ghost->x;
            int ghosty = ghost->y;
            int x = px();
            int y = py();
            bool cond1 = ghostx == x && ghosty == y;
            bool cond2 = (y==ghosty)&&((ghostx-1)==x)&&(ghost->ghost_motion==GHOST_LEFT)&&(pac_motion()==PACMAN_HEADING_RIGHT);
            bool cond3 = (y==ghosty)&&((ghostx+1)==x)&&(ghost->ghost_motion==GHOST_RIGHT)&&(pac_motion()==PACMAN_HEADING_LEFT);
            bool cond4 = (x==ghostx)&&((ghosty-1)==y)&&(ghost->ghost_motion==GHOST_DOWN)&&(pac_motion()==PACMAN_HEADING_UP);
            bool cond5 = (x==ghostx)&&((ghosty+1)==y)&&(ghost->ghost_motion==GHOST_UP)&&(pac_motion()==PACMAN_HEADING_DOWN);
            bool collide = cond1 || cond2 || cond3|| cond4 ||cond5;
            if(collide){
                if(pacman_isInvinc()){
                    ghost = (GHOST *) deleteForward(get_ghost_list());
                    playSound("/sd/wavfiles/BUZZER.wav");
                    pacman_eatGhost();
                } else {
                    pacBlood();
                    uLCD.locate(0,0);
                    uLCD.printf("You died!");
                    playSound("/sd/wavfiles/DEATH.wav");
                    countDown();
                    uLCD.cls();
                    ghost_init();
                    ghost_create(8,7,0xFF0000);
                    ghost_create(9,7,0xFFD5F1);
                    ghost_create(7,7,0x00FFFF);
                    ghost_create(8,6,0xF49629);
                    ghost_show((DLinkedList*)(get_ghost_list));
                    pacman_die(8,9);
                    lives = pacman_getLives();
                    if (lives > -1){
                        map_init();
                        playSound("/sd/wavfiles/START.wav");
                    }
                }
            } else {
                ghost = (GHOST *) getNext(get_ghost_list());
            }
        }
        if (map_remaining_cookie() == 0) { // LVL UP
            uLCD.cls();
            pacman_lvlUp(8,9);
            orientation++;
            ghost_init();
            ghost_create(8,7,0xFF0000);
            ghost_create(9,7,0xFFD5F1);
            ghost_create(7,7,0x00FFFF);
            ghost_create(8,6,0xF49629);
            ghost_show((DLinkedList*)(get_ghost_list));
            map_init();
            playSound("/sd/wavfiles/START.wav");
        }
        }
    }
}



// Sound Extras
void playSound(char * wav)
{
    FILE *wave_file;
    wave_file=fopen(wav,"r");
    waver.play(wave_file);
    fclose(wave_file);
}

// LED Extras
void countDown(){
    int count = 5;
    led = 0;
    myled1 = 1;
    myled2 = 1;
    myled3 = 1;
    myled4 = 1;
    while(count != 0){
        switch(count){
        case 4:
            myled4=0;
            break;
        case 3:
            myled3=0;
            break;
        case 2:
            myled2=0;
            break;
        case 1:
            myled1=0;
            break;
        }
    wait(1);
    led = led + 0.2;
    count--;
    }
    led = 0;
}
